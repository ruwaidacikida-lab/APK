package com.ilive.camera.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ILiveBlack = Color(0xFF050507)
val ILiveSurface = Color(0xFF141418)
val ILiveGlass = Color(0x991C1C22)
val ILiveGold = Color(0xFFFFD60A)
val ILiveWhite = Color(0xFFF5F5F7)
val ILiveGray = Color(0xFF8E8E93)
val ILiveDanger = Color(0xFFFF453A)

private val DarkColorPalette = darkColorScheme(
    primary = ILiveGold,
    onPrimary = Color.Black,
    secondary = ILiveWhite,
    onSecondary = Color.Black,
    background = ILiveBlack,
    onBackground = ILiveWhite,
    surface = ILiveSurface,
    onSurface = ILiveWhite,
    error = ILiveDanger
)

@Composable
fun ILiveCameraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorPalette,
        content = content
    )
}
