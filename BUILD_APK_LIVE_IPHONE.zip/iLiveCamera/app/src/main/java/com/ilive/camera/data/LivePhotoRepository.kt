package com.ilive.camera.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.ilive.camera.model.GalleryDateFilter
import com.ilive.camera.model.GalleryMediaFilter
import com.ilive.camera.model.LivePhotoEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Manages storage, pairing metadata, MediaStore synchronization, and exports for iLive Camera.
 *
 * Pairing Design:
 * - Still photo is saved to MediaStore under `DCIM/iLiveCamera/ILIVE_<TIMESTAMP>_<ID>.jpg`
 * - Motion clip (if Live Photo active) is saved to MediaStore under `DCIM/iLiveCamera/ILIVE_<TIMESTAMP>_<ID>_LIVE.mp4`
 * - Pairing metadata is stored both inside EXIF `UserComment` (`ILIVE_PAIR_ID:<ID>`) and in a fast local JSON index
 *   (`live_photo_index.json`), with automatic MediaStore filename matching fallback so Live Photos remain paired
 *   even if index cache is cleared.
 * - Does not falsely claim Apple proprietary QuickTime ContentIdentifier compatibility; explicitly manages
 *   cross-file pairing on Android and provides dedicated JPEG & MP4 export/share actions.
 */
class LivePhotoRepository(private val context: Context) {

    private val mutex = Mutex()
    private val indexFile = File(context.filesDir, "live_photo_index.json")

    private val _entries = MutableStateFlow<List<LivePhotoEntry>>(emptyList())
    val entries: StateFlow<List<LivePhotoEntry>> = _entries.asStateFlow()

    suspend fun loadEntries() = withContext(Dispatchers.IO) {
        mutex.withLock {
            val loaded = mutableListOf<LivePhotoEntry>()
            val existingIds = mutableSetOf<String>()

            if (indexFile.exists()) {
                try {
                    val raw = indexFile.readText()
                    val array = JSONArray(raw)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val photoUri = Uri.parse(obj.getString("photoUri"))
                        val videoUriStr = obj.optString("videoUri", "")
                        val videoUri = if (videoUriStr.isNotEmpty()) Uri.parse(videoUriStr) else null

                        if (uriExists(photoUri)) {
                            val entry = LivePhotoEntry(
                                id = obj.getString("id"),
                                timestampMs = obj.getLong("timestampMs"),
                                displayName = obj.optString("displayName", "ILIVE_${obj.getString("id")}"),
                                photoUri = photoUri,
                                videoUri = if (videoUri != null && uriExists(videoUri)) videoUri else null,
                                isLivePhoto = obj.optBoolean("isLivePhoto", false) && videoUri != null,
                                width = obj.optInt("width", 3000),
                                height = obj.optInt("height", 4000),
                                resolutionBadge = obj.optString("resolutionBadge", "4:3"),
                                lensFacing = obj.optInt("lensFacing", 1),
                                durationMs = obj.optLong("durationMs", 3000L),
                                sizeBytes = obj.optLong("sizeBytes", 0L)
                            )
                            loaded.add(entry)
                            existingIds.add(entry.id)
                        }
                    }
                } catch (_: Exception) {
                    // Recover gracefully via MediaStore scan below
                }
            }

            // Reconcile with MediaStore in case files were modified externally
            val mediaStoreEntries = scanMediaStoreForILiveMedia(existingIds)
            if (mediaStoreEntries.isNotEmpty()) {
                loaded.addAll(mediaStoreEntries)
            }

            val sorted = loaded.sortedByDescending { it.timestampMs }
            _entries.value = sorted
            persistIndexLocked(sorted)
        }
    }

    suspend fun saveCaptureToMediaStore(
        tempPhotoFile: File,
        tempVideoFile: File?,
        isLivePhoto: Boolean,
        resolutionBadge: String,
        lensFacing: Int,
        durationMs: Long = 3000L
    ): Result<LivePhotoEntry> = withContext(Dispatchers.IO) {
        runCatching {
            val id = UUID.randomUUID().toString().substring(0, 8).uppercase(Locale.US)
            val now = System.currentTimeMillis()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(now))
            val baseName = "ILIVE_${stamp}_$id"

            // Write pairing tag to EXIF UserComment before copying to MediaStore
            var imgWidth = 3000
            var imgHeight = 4000
            try {
                val exif = ExifInterface(tempPhotoFile.absolutePath)
                exif.setAttribute(
                    ExifInterface.TAG_USER_COMMENT,
                    "ILIVE_PAIR_ID:$id|LIVE:$isLivePhoto|RES:$resolutionBadge"
                )
                exif.setAttribute(ExifInterface.TAG_SOFTWARE, "iLive Camera Android 1.0")
                exif.saveAttributes()
                imgWidth = exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 3000).takeIf { it > 0 } ?: 3000
                imgHeight = exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 4000).takeIf { it > 0 } ?: 4000
            } catch (_: Exception) {
                // Non-fatal EXIF tagging
            }

            val photoSize = tempPhotoFile.length()
            val videoSize = if (isLivePhoto && tempVideoFile?.exists() == true) tempVideoFile.length() else 0L

            val photoUri = insertImageIntoMediaStore(tempPhotoFile, "$baseName.jpg", now)
                ?: throw IllegalStateException("Gagal menyimpan foto ke MediaStore")

            var videoUri: Uri? = null
            if (isLivePhoto && tempVideoFile != null && tempVideoFile.exists() && tempVideoFile.length() > 0L) {
                videoUri = insertVideoIntoMediaStore(tempVideoFile, "${baseName}_LIVE.mp4", now, durationMs)
            }

            // Cleanup temp files
            runCatching { tempPhotoFile.delete() }
            runCatching { tempVideoFile?.delete() }

            val newEntry = LivePhotoEntry(
                id = id,
                timestampMs = now,
                displayName = baseName,
                photoUri = photoUri,
                videoUri = videoUri,
                isLivePhoto = isLivePhoto && videoUri != null,
                width = imgWidth,
                height = imgHeight,
                resolutionBadge = resolutionBadge,
                lensFacing = lensFacing,
                durationMs = durationMs,
                sizeBytes = photoSize + videoSize
            )

            mutex.withLock {
                val updated = listOf(newEntry) + _entries.value
                _entries.value = updated
                persistIndexLocked(updated)
            }

            newEntry
        }
    }

    suspend fun deleteEntry(entry: LivePhotoEntry): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            val resolver = context.contentResolver
            runCatching { resolver.delete(entry.photoUri, null, null) }
            entry.videoUri?.let { vUri ->
                runCatching { resolver.delete(vUri, null, null) }
            }
            val updated = _entries.value.filterNot { it.id == entry.id }
            _entries.value = updated
            persistIndexLocked(updated)
            true
        }
    }

    /**
     * Exports a standalone JPEG copy to Pictures/iLiveCamera_Exports for direct sharing or archiving.
     */
    suspend fun exportStandaloneJpeg(entry: LivePhotoEntry): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val exportName = "${entry.displayName}_EXPORT.jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, exportName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/iLiveCamera_Exports")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
            val destUri = resolver.insert(collection, values)
                ?: throw IllegalStateException("Tidak dapat membuat file JPEG ekspor di MediaStore")

            resolver.openInputStream(entry.photoUri)?.use { input ->
                resolver.openOutputStream(destUri)?.use { output ->
                    input.copyTo(output)
                }
            } ?: throw IllegalStateException("File sumber JPEG tidak ditemukan")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val complete = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(destUri, complete, null, null)
            }
            destUri
        }
    }

    /**
     * Exports the Live Photo motion clip as a standalone MP4 file in Movies/iLiveCamera_Exports.
     */
    suspend fun exportStandaloneMp4(entry: LivePhotoEntry): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val sourceVideoUri = entry.videoUri
                ?: throw IllegalStateException("Foto ini tidak memiliki klip gerakan Live Photo")
            val resolver = context.contentResolver
            val exportName = "${entry.displayName}_MOTION.mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, exportName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/iLiveCamera_Exports")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            val destUri = resolver.insert(collection, values)
                ?: throw IllegalStateException("Tidak dapat membuat file MP4 ekspor di MediaStore")

            resolver.openInputStream(sourceVideoUri)?.use { input ->
                resolver.openOutputStream(destUri)?.use { output ->
                    input.copyTo(output)
                }
            } ?: throw IllegalStateException("File sumber video Live Photo tidak ditemukan")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val complete = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(destUri, complete, null, null)
            }
            destUri
        }
    }

    fun createShareIntent(entry: LivePhotoEntry, shareVideoIfAvailable: Boolean): Intent {
        val targetUri = if (shareVideoIfAvailable && entry.videoUri != null) entry.videoUri else entry.photoUri
        val mime = if (shareVideoIfAvailable && entry.videoUri != null) "video/mp4" else "image/jpeg"
        return Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, targetUri)
            putExtra(Intent.EXTRA_TEXT, "Diambil dengan iLive Camera (${if (entry.isLivePhoto) "Live Photo" else "Photo"})")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun filterEntries(
        all: List<LivePhotoEntry>,
        mediaFilter: GalleryMediaFilter,
        dateFilter: GalleryDateFilter
    ): List<LivePhotoEntry> {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()

        val startOfToday = (cal.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val sevenDaysAgo = now - (7L * 24L * 60L * 60L * 1000L)

        val startOfMonth = (cal.clone() as Calendar).apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        return all.filter { item ->
            val mediaMatches = when (mediaFilter) {
                GalleryMediaFilter.ALL -> true
                GalleryMediaFilter.LIVE_ONLY -> item.isLivePhoto
                GalleryMediaFilter.STILL_ONLY -> !item.isLivePhoto
            }
            val dateMatches = when (dateFilter) {
                GalleryDateFilter.ALL_TIME -> true
                GalleryDateFilter.TODAY -> item.timestampMs >= startOfToday
                GalleryDateFilter.LAST_7_DAYS -> item.timestampMs >= sevenDaysAgo
                GalleryDateFilter.THIS_MONTH -> item.timestampMs >= startOfMonth
            }
            mediaMatches && dateMatches
        }
    }

    private fun insertImageIntoMediaStore(file: File, fileName: String, timestampMs: Long): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.DATE_ADDED, timestampMs / 1000)
            put(MediaStore.Images.Media.DATE_TAKEN, timestampMs)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/iLiveCamera")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val uri = resolver.insert(collection, values) ?: return null
        try {
            FileInputStream(file).use { input ->
                resolver.openOutputStream(uri)?.use { output ->
                    input.copyTo(output)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
            return uri
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            return null
        }
    }

    private fun insertVideoIntoMediaStore(file: File, fileName: String, timestampMs: Long, durationMs: Long): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATE_ADDED, timestampMs / 1000)
            put(MediaStore.Video.Media.DATE_TAKEN, timestampMs)
            put(MediaStore.Video.Media.DURATION, durationMs)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/iLiveCamera")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val uri = resolver.insert(collection, values) ?: return null
        try {
            FileInputStream(file).use { input ->
                resolver.openOutputStream(uri)?.use { output ->
                    input.copyTo(output)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
            return uri
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            return null
        }
    }

    private fun uriExists(uri: Uri): Boolean {
        return try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun scanMediaStoreForILiveMedia(existingIds: Set<String>): List<LivePhotoEntry> {
        val discovered = mutableListOf<LivePhotoEntry>()
        try {
            val resolver: ContentResolver = context.contentResolver
            val videoMap = mutableMapOf<String, Uri>()

            // 1. Index matching ILIVE_*_LIVE.mp4 videos
            val videoProjection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME
            )
            val videoSelection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
            val videoArgs = arrayOf("ILIVE_%_LIVE.mp4")

            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoProjection,
                videoSelection,
                videoArgs,
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val mediaId = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val base = name.removeSuffix("_LIVE.mp4")
                    videoMap[base] = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, mediaId)
                }
            }

            // 2. Scan ILIVE_*.jpg images
            val imgProjection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT,
                MediaStore.Images.Media.SIZE
            )
            val imgSelection = "${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
            val imgArgs = arrayOf("ILIVE_%.jpg")

            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                imgProjection,
                imgSelection,
                imgArgs,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val wCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
                val hCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)

                while (cursor.moveToNext()) {
                    val mediaId = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val base = name.removeSuffix(".jpg")
                    val parts = base.split("_")
                    val shortId = if (parts.size >= 4) parts.last() else mediaId.toString()
                    if (existingIds.contains(shortId)) continue

                    val photoUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, mediaId)
                    val pairedVideoUri = videoMap[base]
                    val dateAddedSec = cursor.getLong(dateCol)

                    discovered.add(
                        LivePhotoEntry(
                            id = shortId,
                            timestampMs = dateAddedSec * 1000L,
                            displayName = base,
                            photoUri = photoUri,
                            videoUri = pairedVideoUri,
                            isLivePhoto = pairedVideoUri != null,
                            width = cursor.getInt(wCol).takeIf { it > 0 } ?: 3000,
                            height = cursor.getInt(hCol).takeIf { it > 0 } ?: 4000,
                            resolutionBadge = "4:3",
                            lensFacing = 1,
                            durationMs = 3000L,
                            sizeBytes = cursor.getLong(sizeCol)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // Permission not granted yet or MediaStore unavailable
        }
        return discovered
    }

    private fun persistIndexLocked(list: List<LivePhotoEntry>) {
        try {
            val array = JSONArray()
            for (item in list) {
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("timestampMs", item.timestampMs)
                    put("displayName", item.displayName)
                    put("photoUri", item.photoUri.toString())
                    put("videoUri", item.videoUri?.toString() ?: "")
                    put("isLivePhoto", item.isLivePhoto)
                    put("width", item.width)
                    put("height", item.height)
                    put("resolutionBadge", item.resolutionBadge)
                    put("lensFacing", item.lensFacing)
                    put("durationMs", item.durationMs)
                    put("sizeBytes", item.sizeBytes)
                }
                array.put(obj)
            }
            FileOutputStream(indexFile).use { fos ->
                fos.write(array.toString(2).toByteArray(Charsets.UTF_8))
            }
        } catch (_: Exception) {
            // Ignore write failure
        }
    }
}
