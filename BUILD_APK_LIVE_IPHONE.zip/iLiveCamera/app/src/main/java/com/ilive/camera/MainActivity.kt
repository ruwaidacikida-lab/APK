package com.ilive.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ilive.camera.ui.components.LivePhotoRingsIcon
import com.ilive.camera.ui.screens.CameraScreen
import com.ilive.camera.ui.screens.FullscreenViewerScreen
import com.ilive.camera.ui.screens.GalleryScreen
import com.ilive.camera.ui.theme.ILiveBlack
import com.ilive.camera.ui.theme.ILiveCameraTheme
import com.ilive.camera.ui.theme.ILiveGold
import com.ilive.camera.ui.theme.ILiveGray
import com.ilive.camera.ui.theme.ILiveSurface
import com.ilive.camera.ui.theme.ILiveWhite
import com.ilive.camera.viewmodel.AppScreen
import com.ilive.camera.viewmodel.CameraViewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val viewModel: CameraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ILiveCameraTheme {
                var hasCameraPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { grants ->
                    hasCameraPermission = grants[Manifest.permission.CAMERA] == true ||
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.CAMERA
                        ) == PackageManager.PERMISSION_GRANTED
                }

                LaunchedEffect(Unit) {
                    if (!hasCameraPermission) {
                        permissionLauncher.launch(buildRequiredPermissions())
                    }
                }

                val currentScreen by viewModel.currentScreen.collectAsState()
                val statusToast by viewModel.statusToast.collectAsState()

                LaunchedEffect(statusToast) {
                    if (statusToast != null) {
                        delay(2200L)
                        viewModel.clearToast()
                    }
                }

                BackHandler(enabled = currentScreen != AppScreen.CAMERA) {
                    when (currentScreen) {
                        AppScreen.FULLSCREEN_VIEWER -> viewModel.openGallery()
                        AppScreen.GALLERY -> viewModel.openCamera()
                        AppScreen.CAMERA -> {}
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ILiveBlack)
                ) {
                    if (!hasCameraPermission) {
                        PermissionRequestScreen(
                            onRequestPermissions = {
                                permissionLauncher.launch(buildRequiredPermissions())
                            },
                            onOpenAppSettings = {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", packageName, null)
                                )
                                startActivity(intent)
                            }
                        )
                    } else {
                        when (currentScreen) {
                            AppScreen.CAMERA -> CameraScreen(viewModel = viewModel)
                            AppScreen.GALLERY -> GalleryScreen(viewModel = viewModel)
                            AppScreen.FULLSCREEN_VIEWER -> FullscreenViewerScreen(viewModel = viewModel)
                        }
                    }

                    // Minimalist Status Pill Notification
                    AnimatedVisibility(
                        visible = statusToast != null,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .padding(top = 68.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(ILiveSurface.copy(alpha = 0.92f))
                                .border(1.dp, ILiveGold.copy(alpha = 0.45f), RoundedCornerShape(50))
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = statusToast ?: "",
                                color = ILiveWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }

    private fun buildRequiredPermissions(): Array<String> {
        val list = mutableListOf(
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.READ_MEDIA_IMAGES)
            list.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            list.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return list.toTypedArray()
    }
}

@Composable
private fun PermissionRequestScreen(
    onRequestPermissions: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LivePhotoRingsIcon(active = true, isPlayingOrRecording = true, size = 64.dp)
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Izin Kamera Diperlukan",
            color = ILiveWhite,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "iLive Camera membutuhkan akses kamera untuk menampilkan pratinjau real-time dan merekam momen Live Photo (1.5 detik sebelum & sesudah tombol shutter ditekan). Semua foto dan klip disimpan 100% secara lokal di perangkat Anda tanpa pengumpulan data pribadi.",
            color = ILiveGray,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            lineHeight = 20.sp
        )
        Spacer(modifier = Modifier.height(28.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(ILiveGold)
                .clickable { onRequestPermissions() }
                .padding(vertical = 15.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Berikan Izin Kamera & Media",
                color = Color.Black,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(ILiveSurface)
                .clickable { onOpenAppSettings() }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Buka Pengaturan Aplikasi",
                color = ILiveWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
