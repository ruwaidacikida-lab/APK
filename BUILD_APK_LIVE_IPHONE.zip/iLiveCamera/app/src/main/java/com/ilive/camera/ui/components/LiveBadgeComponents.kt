package com.ilive.camera.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ilive.camera.ui.theme.ILiveGold
import com.ilive.camera.ui.theme.ILiveGray
import com.ilive.camera.ui.theme.ILiveWhite

/**
 * Iconic concentric Live Photo rings icon inspired by iOS Live Photos with a distinct
 * modern minimalist aesthetic.
 */
@Composable
fun LivePhotoRingsIcon(
    active: Boolean,
    isPlayingOrRecording: Boolean = false,
    size: Dp = 22.dp,
    tint: Color = if (active) ILiveGold else ILiveWhite
) {
    val infiniteTransition = rememberInfiniteTransition(label = "live_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isPlayingOrRecording) 1.16f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val animatedColor by animateColorAsState(
        targetValue = tint,
        animationSpec = tween(250),
        label = "ring_color"
    )

    Canvas(
        modifier = Modifier
            .size(size)
            .scale(if (isPlayingOrRecording) pulseScale else 1f)
    ) {
        val center = this.center
        val outerRadius = this.size.minDimension * 0.44f
        val midRadius = this.size.minDimension * 0.28f
        val innerRadius = this.size.minDimension * 0.13f

        // Outer dotted ring (signature Live Photo aura)
        drawCircle(
            color = animatedColor,
            radius = outerRadius,
            center = center,
            style = Stroke(
                width = 1.6.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.5f, 4.5f), 0f)
            )
        )

        // Middle continuous ring
        drawCircle(
            color = animatedColor,
            radius = midRadius,
            center = center,
            style = Stroke(width = 1.6.dp.toPx())
        )

        // Solid inner core
        drawCircle(
            color = animatedColor,
            radius = innerRadius,
            center = center
        )

        // Slash line when Live Photo is disabled
        if (!active) {
            drawLine(
                color = ILiveGray,
                start = androidx.compose.ui.geometry.Offset(this.size.width * 0.15f, this.size.height * 0.85f),
                end = androidx.compose.ui.geometry.Offset(this.size.width * 0.85f, this.size.height * 0.15f),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}

@Composable
fun LiveStatusPill(
    isLiveEnabled: Boolean,
    isCapturingOrPlaying: Boolean,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = if (isLiveEnabled) ILiveGold.copy(alpha = 0.18f) else Color.Black.copy(alpha = 0.45f),
        animationSpec = tween(250),
        label = "pill_bg"
    )
    val borderColor by animateColorAsState(
        targetValue = if (isLiveEnabled) ILiveGold.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.2f),
        animationSpec = tween(250),
        label = "pill_border"
    )
    val textColor by animateColorAsState(
        targetValue = if (isLiveEnabled) ILiveGold else ILiveWhite.copy(alpha = 0.75f),
        animationSpec = tween(250),
        label = "pill_text"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(50))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 11.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LivePhotoRingsIcon(
                active = isLiveEnabled,
                isPlayingOrRecording = isCapturingOrPlaying,
                size = 16.dp,
                tint = textColor
            )
            Text(
                text = if (isLiveEnabled) "LIVE" else "LIVE OFF",
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.8.sp
            )
        }
    }
}
