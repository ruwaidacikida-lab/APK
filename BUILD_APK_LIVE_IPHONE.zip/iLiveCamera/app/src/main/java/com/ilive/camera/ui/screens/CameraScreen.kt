package com.ilive.camera.ui.screens

import android.view.OrientationEventListener
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.ilive.camera.model.CameraCaptureMode
import com.ilive.camera.model.CaptureResolution
import com.ilive.camera.model.FlashState
import com.ilive.camera.ui.components.LivePhotoRingsIcon
import com.ilive.camera.ui.components.LiveStatusPill
import com.ilive.camera.ui.theme.ILiveBlack
import com.ilive.camera.ui.theme.ILiveGold
import com.ilive.camera.ui.theme.ILiveGray
import com.ilive.camera.ui.theme.ILiveSurface
import com.ilive.camera.ui.theme.ILiveWhite
import com.ilive.camera.viewmodel.CameraViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(
    viewModel: CameraViewModel
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val isLiveEnabled by viewModel.isLivePhotoEnabled.collectAsState()
    val flashState by viewModel.flashState.collectAsState()
    val lensFacing by viewModel.lensFacing.collectAsState()
    val resolution by viewModel.resolution.collectAsState()
    val captureMode by viewModel.captureMode.collectAsState()
    val isCapturing by viewModel.isCapturing.collectAsState()
    val shutterFlash by viewModel.shutterFlashEffect.collectAsState()
    val allEntries by viewModel.allEntries.collectAsState()
    val zoomRatio by viewModel.cameraController.zoomRatio.collectAsState()
    val isCameraReady by viewModel.cameraController.isCameraReady.collectAsState()
    val deviceRotation by viewModel.cameraController.deviceRotationDegrees.collectAsState()
    val showSettingsSheet by viewModel.showSettingsSheet.collectAsState()
    val enableGridLines by viewModel.enableGridLines.collectAsState()

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    var focusTapOffset by remember { mutableStateOf<Offset?>(null) }

    // Track physical orientation for smooth icon rotation and EXIF rotation
    DisposableEffect(context) {
        val listener = object : OrientationEventListener(context) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val snapped = when (orientation) {
                    in 45..134 -> 270
                    in 135..224 -> 180
                    in 225..314 -> 90
                    else -> 0
                }
                viewModel.cameraController.updateDeviceRotation(snapped)
            }
        }
        listener.enable()
        onDispose { listener.disable() }
    }

    // Bind CameraX whenever lensFacing or resolution changes
    LaunchedEffect(lensFacing, resolution) {
        viewModel.cameraController.bindCamera(
            lifecycleOwner = lifecycleOwner,
            previewView = previewView,
            lensFacing = lensFacing,
            flashState = flashState,
            resolution = resolution,
            livePhotoEnabled = isLiveEnabled
        )
    }

    // Auto-clear focus indicator after 1.6s
    LaunchedEffect(focusTapOffset) {
        if (focusTapOffset != null) {
            delay(1600L)
            focusTapOffset = null
        }
    }

    val iconRotation by animateFloatAsState(
        targetValue = when (deviceRotation) {
            90 -> 90f
            180 -> 180f
            270 -> -90f
            else -> 0f
        },
        animationSpec = tween(250),
        label = "icon_rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ILiveBlack)
    ) {
        // 1. Fullscreen Camera Preview Area with Pinch-to-Zoom & Tap-to-Focus
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, _, zoomChange, _ ->
                        if (zoomChange != 1f) {
                            viewModel.cameraController.onPinchZoom(zoomChange)
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        focusTapOffset = offset
                        viewModel.cameraController.triggerTapToFocus(
                            previewView = previewView,
                            x = offset.x,
                            y = offset.y
                        )
                        viewModel.haptics.performModeTick()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(resolution.aspectRatioFloat)
                    .clip(RoundedCornerShape(18.dp))
            )

            // Rule-of-thirds composition grid
            if (enableGridLines) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(resolution.aspectRatioFloat)
                ) {
                    val w = size.width
                    val h = size.height
                    val gridColor = Color.White.copy(alpha = 0.18f)
                    drawLine(gridColor, Offset(w / 3f, 0f), Offset(w / 3f, h), strokeWidth = 1f)
                    drawLine(gridColor, Offset(2f * w / 3f, 0f), Offset(2f * w / 3f, h), strokeWidth = 1f)
                    drawLine(gridColor, Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth = 1f)
                    drawLine(gridColor, Offset(0f, 2f * h / 3f), Offset(w, 2f * h / 3f), strokeWidth = 1f)
                }
            }

            // Tap-to-Focus animated reticle (iPhone-inspired yellow focus square)
            focusTapOffset?.let { tapPos ->
                val boxSizePx = with(LocalDensity.current) { 72.dp.toPx() }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (tapPos.x - boxSizePx / 2).roundToInt(),
                                    (tapPos.y - boxSizePx / 2).roundToInt()
                                )
                            }
                            .size(72.dp)
                            .border(1.5.dp, ILiveGold, RoundedCornerShape(6.dp))
                    )
                }
            }

            // Elegant loading state while switching camera or binding sensor
            AnimatedVisibility(
                visible = !isCameraReady,
                enter = fadeIn(tween(150)),
                exit = fadeOut(tween(250))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.65f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        LivePhotoRingsIcon(active = true, isPlayingOrRecording = true, size = 36.dp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Menginisialisasi Sensor...",
                            color = ILiveWhite.copy(alpha = 0.8f),
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Visual Shutter Flash Feedback
            AnimatedVisibility(
                visible = shutterFlash,
                enter = fadeIn(tween(40)),
                exit = fadeOut(tween(120))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.White.copy(alpha = 0.72f))
                )
            }
        }

        // 2. Top Minimalist Control Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
                .align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Flash Button
                IconButton(
                    onClick = { viewModel.cycleFlashState() },
                    modifier = Modifier
                        .size(40.dp)
                        .rotate(iconRotation)
                ) {
                    val icon = when (flashState) {
                        FlashState.AUTO -> Icons.Default.FlashAuto
                        FlashState.ON -> Icons.Default.FlashOn
                        FlashState.OFF -> Icons.Default.FlashOff
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = "Flash ${flashState.label}",
                        tint = if (flashState == FlashState.ON) ILiveGold else ILiveWhite
                    )
                }

                // Live Photo Toggle Pill
                LiveStatusPill(
                    isLiveEnabled = isLiveEnabled,
                    isCapturingOrPlaying = isCapturing && isLiveEnabled,
                    onClick = { viewModel.toggleLivePhoto() }
                )

                // Resolution Badge Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .clickable { viewModel.cycleResolution() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = resolution.badge,
                        color = ILiveWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Settings Sheet Trigger
                IconButton(
                    onClick = { viewModel.setSettingsSheetVisible(true) },
                    modifier = Modifier
                        .size(40.dp)
                        .rotate(iconRotation)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Pengaturan Kamera",
                        tint = ILiveWhite
                    )
                }
            }

            // Live Photo Recording Banner when shutter is capturing post-shutter motion
            AnimatedVisibility(
                visible = isCapturing && isLiveEnabled,
                enter = fadeIn(tween(150)),
                exit = fadeOut(tween(200))
            ) {
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(ILiveGold)
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "LIVE RECORDING",
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // 3. Bottom Control Deck (Zoom Pills + Mode Selector + Shutter + Last Thumbnail + Lens Switch)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 18.dp)
                .align(Alignment.BottomCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Quick Optical/Digital Zoom Preset Pills (1x, 2x, 3x)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.48f))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(1.0f, 2.0f, 3.0f).forEach { preset ->
                    val isSelected = kotlin.math.abs(zoomRatio - preset) < 0.25f
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) ILiveWhite.copy(alpha = 0.22f) else Color.Transparent)
                            .clickable {
                                viewModel.cameraController.setZoomRatio(preset)
                                viewModel.haptics.performModeTick()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isSelected) String.format("%.1fx", zoomRatio) else "${preset.toInt()}x",
                            color = if (isSelected) ILiveGold else ILiveWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Camera Mode Selector Row (LIVE | PHOTO | PORTRAIT)
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CameraCaptureMode.values().forEach { mode ->
                    val selected = captureMode == mode
                    Text(
                        text = mode.displayName,
                        color = if (selected) ILiveGold else ILiveWhite.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        letterSpacing = 1.2.sp,
                        modifier = Modifier
                            .clickable { viewModel.selectCaptureMode(mode) }
                            .padding(vertical = 4.dp, horizontal = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Lower Row: Gallery Thumbnail | Responsive Circular Shutter | Flip Camera
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Last Captured Photo Thumbnail (opens iLive Gallery)
                val latestEntry = allEntries.firstOrNull()
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(ILiveSurface)
                        .border(1.5.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .clickable { viewModel.openGallery() },
                    contentAlignment = Alignment.Center
                ) {
                    if (latestEntry != null) {
                        AsyncImage(
                            model = latestEntry.photoUri,
                            contentDescription = "Foto Terakhir",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (latestEntry.isLivePhoto) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(ILiveGold)
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Buka Galeri",
                            tint = ILiveWhite.copy(alpha = 0.75f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Responsive iPhone-inspired Circular Shutter Button
                val interactionSource = remember { MutableInteractionSource() }
                val isPressed by interactionSource.collectIsPressedAsState()
                val shutterScale by animateFloatAsState(
                    targetValue = when {
                        isPressed -> 0.86f
                        isCapturing -> 0.92f
                        else -> 1.0f
                    },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    ),
                    label = "shutter_scale"
                )

                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clickable(
                            interactionSource = interactionSource,
                            indication = null,
                            enabled = !isCapturing
                        ) {
                            viewModel.capturePhoto()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    // Outer metallic/gold ring
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = if (isLiveEnabled) ILiveGold else ILiveWhite,
                            style = Stroke(width = 4.dp.toPx())
                        )
                    }
                    // Inner responsive shutter disc
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .scale(shutterScale)
                            .clip(CircleShape)
                            .background(if (isCapturing && isLiveEnabled) ILiveGold else ILiveWhite)
                    )
                }

                // Switch Front / Back Camera Button
                IconButton(
                    onClick = { viewModel.switchCameraLens() },
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                        .rotate(iconRotation)
                ) {
                    Icon(
                        imageVector = Icons.Default.Cameraswitch,
                        contentDescription = "Ganti Kamera Depan/Belakang",
                        tint = ILiveWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }

        // 4. Camera Settings Modal Bottom Sheet
        if (showSettingsSheet) {
            ModalBottomSheet(
                onDismissRequest = { viewModel.setSettingsSheetVisible(false) },
                containerColor = ILiveSurface,
                contentColor = ILiveWhite
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Pengaturan iLive Camera",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = ILiveWhite
                    )

                    // Live Photo Setting Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Rekam Live Photo (3.0 Detik)", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text(
                                "Menyimpan 1.5 detik sebelum & 1.5 detik sesudah tombol shutter ditekan",
                                color = ILiveGray,
                                fontSize = 12.sp
                            )
                        }
                        Switch(
                            checked = isLiveEnabled,
                            onCheckedChange = { viewModel.toggleLivePhoto() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = ILiveGold)
                        )
                    }

                    // Grid Lines Setting Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Garis Bantu Komposisi (Grid 3x3)", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("Tampilkan garis rule-of-thirds pada layar preview", color = ILiveGray, fontSize = 12.sp)
                        }
                        Switch(
                            checked = enableGridLines,
                            onCheckedChange = { viewModel.toggleGridLines() },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = ILiveGold)
                        )
                    }

                    // Resolution Picker
                    Text("Resolusi & Rasio Foto", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CaptureResolution.values().forEach { res ->
                            val active = res == resolution
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (active) ILiveGold else Color.White.copy(alpha = 0.08f))
                                    .clickable { viewModel.selectResolution(res) }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = res.badge,
                                        color = if (active) Color.Black else ILiveWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${res.targetSize.width}x${res.targetSize.height}",
                                        color = if (active) Color.Black.copy(alpha = 0.75f) else ILiveGray,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                }
            }
        }
    }
}
