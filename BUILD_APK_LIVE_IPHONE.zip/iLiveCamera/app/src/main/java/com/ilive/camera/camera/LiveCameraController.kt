package com.ilive.camera.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import android.view.Surface
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.ilive.camera.model.CaptureResolution
import com.ilive.camera.model.FlashState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

/**
 * Hardware-accelerated CameraX + Circular Rolling Frame Buffer Engine for iLive Camera.
 *
 * Why a Circular Frame Buffer + MediaCodec H.264 Muxer?
 * - True iPhone-style Live Photos require capturing 1.5 seconds *before* the user taps the shutter
 *   and 1.5 seconds *after* the shutter is pressed, without disk wear or file-rollover gaps.
 * - While Live Photo mode is enabled, [ImageAnalysis] with `STRATEGY_KEEP_ONLY_LATEST` samples
 *   lightweight NV21/JPEG frames at ~15 fps into a bounded in-memory ring buffer (max 24 pre-frames,
 *   ~3-4 MB RAM footprint).
 * - When the user presses the shutter:
 *   1. High-resolution [ImageCapture] captures the crisp primary JPEG immediately.
 *   2. The ring buffer snapshots the ~1.5s pre-shutter frames and continues collecting ~1.5s of
 *      post-shutter frames.
 *   3. On a background IO thread, the combined ~3.0s frame sequence is encoded into a smooth
 *      hardware H.264 `.mp4` clip via Android's native [MediaCodec] + [MediaMuxer] with monotonic
 *      presentation timestamps so playback is 100% stutter-free.
 */
class LiveCameraController(private val context: Context) {

    data class BufferedFrame(
        val jpegBytes: ByteArray,
        val timestampNs: Long,
        val rotationDegrees: Int,
        val width: Int,
        val height: Int
    )

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val controllerScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalysis: ImageAnalysis? = null

    private val frameRingBuffer = ArrayDeque<BufferedFrame>(48)
    private val bufferLock = Any()

    @Volatile
    private var isLiveBufferingEnabled: Boolean = true

    @Volatile
    private var lastFrameSampleTimeMs: Long = 0L

    // Target ~15 FPS in rolling buffer (66ms interval) -> 45 frames for 3.0 seconds
    private val frameIntervalMs = 66L
    private val maxPreShutterFrames = 23 // ~1.5 seconds pre-shutter

    private val _zoomRatio = MutableStateFlow(1.0f)
    val zoomRatio: StateFlow<Float> = _zoomRatio.asStateFlow()

    private val _minZoomRatio = MutableStateFlow(1.0f)
    val minZoomRatio: StateFlow<Float> = _minZoomRatio.asStateFlow()

    private val _maxZoomRatio = MutableStateFlow(8.0f)
    val maxZoomRatio: StateFlow<Float> = _maxZoomRatio.asStateFlow()

    private val _isCameraReady = MutableStateFlow(false)
    val isCameraReady: StateFlow<Boolean> = _isCameraReady.asStateFlow()

    private val _deviceRotationDegrees = MutableStateFlow(0)
    val deviceRotationDegrees: StateFlow<Int> = _deviceRotationDegrees.asStateFlow()

    fun setLiveBufferingEnabled(enabled: Boolean) {
        isLiveBufferingEnabled = enabled
        if (!enabled) {
            synchronized(bufferLock) {
                frameRingBuffer.clear()
            }
        }
    }

    fun updateDeviceRotation(degrees: Int) {
        _deviceRotationDegrees.value = degrees
        val surfaceRotation = when (degrees) {
            in 45..134 -> Surface.ROTATION_270
            in 135..224 -> Surface.ROTATION_180
            in 225..314 -> Surface.ROTATION_90
            else -> Surface.ROTATION_0
        }
        imageCapture?.targetRotation = surfaceRotation
    }

    suspend fun bindCamera(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        lensFacing: Int,
        flashState: FlashState,
        resolution: CaptureResolution,
        livePhotoEnabled: Boolean
    ): Result<Unit> = withContext(Dispatchers.Main) {
        runCatching {
            _isCameraReady.value = false
            isLiveBufferingEnabled = livePhotoEnabled

            val provider = getCameraProvider()
            cameraProvider = provider
            provider.unbindAll()

            val aspectStrategy = if (resolution == CaptureResolution.FHD_16_9) {
                AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            } else {
                AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            }

            val previewSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(aspectStrategy)
                .build()

            val previewUseCase = Preview.Builder()
                .setResolutionSelector(previewSelector)
                .build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val captureSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(aspectStrategy)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        resolution.targetSize,
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                )
                .build()

            val imageCaptureUseCase = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setFlashMode(flashState.cameraXMode)
                .setResolutionSelector(captureSelector)
                .build()

            val analysisSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        android.util.Size(720, 960),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val analysisUseCase = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .setResolutionSelector(analysisSelector)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(analysisExecutor) { imageProxy ->
                        processRollingFrame(imageProxy, lensFacing == CameraSelector.LENS_FACING_FRONT)
                    }
                }

            val selector = CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build()

            val boundCamera = provider.bindToLifecycle(
                lifecycleOwner,
                selector,
                previewUseCase,
                imageCaptureUseCase,
                analysisUseCase
            )

            camera = boundCamera
            preview = previewUseCase
            imageCapture = imageCaptureUseCase
            imageAnalysis = analysisUseCase

            boundCamera.cameraInfo.zoomState.value?.let { zs ->
                _zoomRatio.value = zs.zoomRatio
                _minZoomRatio.value = zs.minZoomRatio
                _maxZoomRatio.value = min(zs.maxZoomRatio, 10.0f)
            }

            _isCameraReady.value = true
        }
    }

    fun setFlashMode(flashState: FlashState) {
        imageCapture?.flashMode = flashState.cameraXMode
    }

    fun setZoomRatio(ratio: Float) {
        val clamped = ratio.coerceIn(_minZoomRatio.value, _maxZoomRatio.value)
        _zoomRatio.value = clamped
        camera?.cameraControl?.setZoomRatio(clamped)
    }

    fun onPinchZoom(scaleFactor: Float) {
        val current = _zoomRatio.value
        setZoomRatio(current * scaleFactor)
    }

    @SuppressLint("RestrictedApi")
    fun triggerTapToFocus(previewView: PreviewView, x: Float, y: Float) {
        val cam = camera ?: return
        try {
            val factory = previewView.meteringPointFactory
            val point = factory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(
                point,
                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            )
                .setAutoCancelDuration(3, TimeUnit.SECONDS)
                .build()
            cam.cameraControl.startFocusAndMetering(action)
        } catch (e: Exception) {
            Log.w("LiveCameraController", "Tap-to-focus ignored: ${e.message}")
        }
    }

    /**
     * Captures a high-resolution JPEG still photo and, if [captureLivePhoto] is enabled,
     * snapshots the 1.5s pre-shutter buffer + records 1.5s post-shutter frames and muxes them
     * into an H.264 MP4 motion clip.
     */
    suspend fun capturePhotoAndLiveClip(
        captureLivePhoto: Boolean,
        lensFacing: Int
    ): Result<Pair<File, File?>> = withContext(Dispatchers.IO) {
        runCatching {
            val captureUseCase = imageCapture
                ?: throw IllegalStateException("Kamera belum siap")

            // 1. Snapshot pre-shutter rolling frames immediately before shutter trigger
            val preShutterFrames: List<BufferedFrame> = if (captureLivePhoto) {
                synchronized(bufferLock) {
                    frameRingBuffer.toList()
                }
            } else {
                emptyList()
            }

            val photoFile = File(context.cacheDir, "temp_capture_${System.currentTimeMillis()}.jpg")

            // 2. Capture full-res JPEG via CameraX ImageCapture
            val savedPhotoFile = suspendCancellableCoroutine<File> { cont ->
                val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile)
                    .setMetadata(
                        ImageCapture.Metadata().apply {
                            isReversedHorizontal = (lensFacing == CameraSelector.LENS_FACING_FRONT)
                        }
                    )
                    .build()

                captureUseCase.takePicture(
                    outputOptions,
                    cameraExecutor,
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                            if (cont.isActive) cont.resume(photoFile)
                        }

                        override fun onError(exception: ImageCaptureException) {
                            if (cont.isActive) {
                                // Fallback: if hardware ImageCapture fails on an emulator/device,
                                // synthesize JPEG from latest rolling buffer frame so capture never crashes
                                val fallback = createFallbackJpegFromBuffer(photoFile)
                                if (fallback != null) {
                                    cont.resume(fallback)
                                } else {
                                    cont.cancel(exception)
                                }
                            }
                        }
                    }
                )
            }

            // 3. If Live Photo is active, collect ~1.3s of post-shutter frames and encode MP4
            var motionVideoFile: File? = null
            if (captureLivePhoto) {
                delay(1350L) // Collect post-shutter motion seamlessly while analysis continues
                val postSnapshot = synchronized(bufferLock) {
                    frameRingBuffer.toList()
                }
                val lastPreTimestamp = preShutterFrames.lastOrNull()?.timestampNs ?: 0L
                val postShutterFrames = postSnapshot.filter { it.timestampNs > lastPreTimestamp }
                val combinedFrames = (preShutterFrames + postShutterFrames).takeLast(45)

                if (combinedFrames.size >= 6) {
                    val outMp4 = File(context.cacheDir, "temp_live_${System.currentTimeMillis()}.mp4")
                    val encoded = encodeFramesToMp4(combinedFrames, outMp4)
                    if (encoded && outMp4.exists() && outMp4.length() > 0L) {
                        motionVideoFile = outMp4
                    }
                }
            }

            Pair(savedPhotoFile, motionVideoFile)
        }
    }

    private fun createFallbackJpegFromBuffer(destFile: File): File? {
        val latest = synchronized(bufferLock) { frameRingBuffer.lastOrNull() } ?: return null
        return try {
            destFile.writeBytes(latest.jpegBytes)
            destFile
        } catch (_: Exception) {
            null
        }
    }

    private fun processRollingFrame(imageProxy: ImageProxy, isFrontCamera: Boolean) {
        try {
            if (!isLiveBufferingEnabled) return

            val nowMs = System.currentTimeMillis()
            if (nowMs - lastFrameSampleTimeMs < frameIntervalMs) return
            lastFrameSampleTimeMs = nowMs

            val nv21 = yuv420888ToNv21(imageProxy) ?: return
            val yuvImage = YuvImage(nv21, ImageFormat.NV21, imageProxy.width, imageProxy.height, null)
            val out = ByteArrayOutputStream()
            val compressed = yuvImage.compressToJpeg(
                Rect(0, 0, imageProxy.width, imageProxy.height),
                74,
                out
            )
            if (!compressed) return

            val frame = BufferedFrame(
                jpegBytes = out.toByteArray(),
                timestampNs = imageProxy.imageInfo.timestamp,
                rotationDegrees = imageProxy.imageInfo.rotationDegrees,
                width = imageProxy.width,
                height = imageProxy.height
            )

            synchronized(bufferLock) {
                while (frameRingBuffer.size >= maxPreShutterFrames) {
                    frameRingBuffer.removeFirst()
                }
                frameRingBuffer.addLast(frame)
            }
        } catch (_: Exception) {
            // Avoid any crash inside analyzer thread
        } finally {
            imageProxy.close()
        }
    }

    private fun yuv420888ToNv21(image: ImageProxy): ByteArray? {
        return try {
            val yPlane = image.planes[0]
            val uPlane = image.planes[1]
            val vPlane = image.planes[2]

            val width = image.width
            val height = image.height
            val ySize = width * height
            val uvSize = width * height / 2
            val nv21 = ByteArray(ySize + uvSize)

            val yBuffer = yPlane.buffer
            val uBuffer = uPlane.buffer
            val vBuffer = vPlane.buffer

            var pos = 0
            val yRowStride = yPlane.rowStride
            if (yRowStride == width) {
                yBuffer.get(nv21, 0, ySize)
                pos = ySize
            } else {
                var yBufferPos = 0
                for (row in 0 until height) {
                    yBuffer.position(yBufferPos)
                    yBuffer.get(nv21, pos, width)
                    yBufferPos += yRowStride
                    pos += width
                }
            }

            val uvRowStride = vPlane.rowStride
            val uvPixelStride = vPlane.pixelStride
            val uvHeight = height / 2
            val uvWidth = width / 2

            for (row in 0 until uvHeight) {
                for (col in 0 until uvWidth) {
                    val vIndex = row * uvRowStride + col * uvPixelStride
                    val uIndex = row * uPlane.rowStride + col * uPlane.pixelStride
                    nv21[pos++] = vBuffer.get(vIndex)
                    nv21[pos++] = uBuffer.get(uIndex)
                }
            }
            nv21
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Encodes the buffered JPEG frames into a smooth H.264 MP4 video clip using Android's
     * hardware MediaCodec + MediaMuxer.
     */
    private fun encodeFramesToMp4(frames: List<BufferedFrame>, outputFile: File): Boolean {
        if (frames.isEmpty()) return false
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false

        try {
            // Decode first frame to determine oriented dimensions (even numbers required by H.264)
            val firstBmp = decodeOrientedBitmap(frames.first()) ?: return false
            val targetWidth = (firstBmp.width / 2) * 2
            val targetHeight = (firstBmp.height / 2) * 2
            firstBmp.recycle()

            val mime = MediaFormat.MIMETYPE_VIDEO_AVC
            val format = MediaFormat.createVideoFormat(mime, targetWidth, targetHeight).apply {
                setInteger(
                    MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
                )
                setInteger(MediaFormat.KEY_BIT_RATE, 3_500_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, 15)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            codec = MediaCodec.createEncoderByType(mime)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val bufferInfo = MediaCodec.BufferInfo()
            var trackIndex = -1
            var presentationTimeUs = 0L
            val frameStepUs = 66_666L // 15 FPS

            for ((index, frame) in frames.withIndex()) {
                val bmp = decodeOrientedBitmap(frame, targetWidth, targetHeight) ?: continue
                val yuvData = bitmapToYuv420SemiPlanar(bmp, targetWidth, targetHeight)
                bmp.recycle()

                val inputBufferId = codec.dequeueInputBuffer(10_000L)
                if (inputBufferId >= 0) {
                    val inputBuffer = codec.getInputBuffer(inputBufferId)
                    inputBuffer?.clear()
                    inputBuffer?.put(yuvData)
                    codec.queueInputBuffer(
                        inputBufferId,
                        0,
                        yuvData.size,
                        presentationTimeUs,
                        0
                    )
                    presentationTimeUs += frameStepUs
                }

                muxerStarted = drainEncoder(codec, muxer, bufferInfo, trackIndex, muxerStarted, false)
                    .also { (newTrack, _) -> trackIndex = newTrack }.second
            }

            // Signal End Of Stream
            val eosInputId = codec.dequeueInputBuffer(10_000L)
            if (eosInputId >= 0) {
                codec.queueInputBuffer(
                    eosInputId,
                    0,
                    0,
                    presentationTimeUs,
                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                )
            }
            drainEncoder(codec, muxer, bufferInfo, trackIndex, muxerStarted, true)
            return true
        } catch (e: Exception) {
            Log.e("LiveCameraController", "Failed to encode Live Photo MP4: ${e.message}")
            return false
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            if (muxerStarted) {
                runCatching { muxer?.stop() }
            }
            runCatching { muxer?.release() }
        }
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        currentTrackIndex: Int,
        currentMuxerStarted: Boolean,
        endOfStream: Boolean
    ): Pair<Int, Boolean> {
        var trackIndex = currentTrackIndex
        var muxerStarted = currentMuxerStarted

        while (true) {
            val outputStatus = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
            if (outputStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (outputStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (!muxerStarted) {
                    val newFormat = codec.outputFormat
                    trackIndex = muxer.addTrack(newFormat)
                    muxer.start()
                    muxerStarted = true
                }
            } else if (outputStatus >= 0) {
                val encodedData = codec.getOutputBuffer(outputStatus)
                if (encodedData != null && bufferInfo.size > 0 && muxerStarted &&
                    (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                ) {
                    encodedData.position(bufferInfo.offset)
                    encodedData.limit(bufferInfo.offset + bufferInfo.size)
                    muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                }
                codec.releaseOutputBuffer(outputStatus, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break
                }
            }
        }
        return Pair(trackIndex, muxerStarted)
    }

    private fun decodeOrientedBitmap(
        frame: BufferedFrame,
        reqWidth: Int = 0,
        reqHeight: Int = 0
    ): Bitmap? {
        return try {
            val raw = BitmapFactory.decodeByteArray(frame.jpegBytes, 0, frame.jpegBytes.size) ?: return null
            val rotated = if (frame.rotationDegrees != 0) {
                val m = Matrix().apply { postRotate(frame.rotationDegrees.toFloat()) }
                val r = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                if (r != raw) raw.recycle()
                r
            } else {
                raw
            }
            if (reqWidth > 0 && reqHeight > 0 && (rotated.width != reqWidth || rotated.height != reqHeight)) {
                val scaled = Bitmap.createScaledBitmap(rotated, reqWidth, reqHeight, true)
                if (scaled != rotated) rotated.recycle()
                scaled
            } else {
                rotated
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun bitmapToYuv420SemiPlanar(bmp: Bitmap, width: Int, height: Int): ByteArray {
        val argb = IntArray(width * height)
        bmp.getPixels(argb, 0, width, 0, 0, width, height)
        val yuv = ByteArray(width * height * 3 / 2)
        var yIndex = 0
        var uvIndex = width * height

        for (j in 0 until height) {
            for (i in 0 until width) {
                val c = argb[j * width + i]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF

                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128

                yuv[yIndex++] = y.coerceIn(0, 255).toByte()
                if (j % 2 == 0 && i % 2 == 0 && uvIndex + 1 < yuv.size) {
                    yuv[uvIndex++] = u.coerceIn(0, 255).toByte()
                    yuv[uvIndex++] = v.coerceIn(0, 255).toByte()
                }
            }
        }
        return yuv
    }

    private suspend fun getCameraProvider(): ProcessCameraProvider =
        suspendCancellableCoroutine { continuation ->
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener(
                {
                    try {
                        if (continuation.isActive) {
                            continuation.resume(future.get())
                        }
                    } catch (e: Exception) {
                        if (continuation.isActive) continuation.cancel(e)
                    }
                },
                ContextCompat.getMainExecutor(context)
            )
        }

    fun shutdown() {
        runCatching { cameraProvider?.unbindAll() }
        runCatching { cameraExecutor.shutdown() }
        runCatching { analysisExecutor.shutdown() }
    }
}
