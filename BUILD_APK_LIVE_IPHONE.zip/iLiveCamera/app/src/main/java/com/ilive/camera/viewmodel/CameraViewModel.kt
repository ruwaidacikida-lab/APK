package com.ilive.camera.viewmodel

import android.app.Application
import android.content.Intent
import androidx.camera.core.CameraSelector
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ilive.camera.camera.LiveCameraController
import com.ilive.camera.data.LivePhotoRepository
import com.ilive.camera.model.CameraCaptureMode
import com.ilive.camera.model.CaptureResolution
import com.ilive.camera.model.FlashState
import com.ilive.camera.model.GalleryDateFilter
import com.ilive.camera.model.GalleryMediaFilter
import com.ilive.camera.model.LivePhotoEntry
import com.ilive.camera.util.HapticFeedbackManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    CAMERA,
    GALLERY,
    FULLSCREEN_VIEWER
}

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    val repository = LivePhotoRepository(application.applicationContext)
    val cameraController = LiveCameraController(application.applicationContext)
    val haptics = HapticFeedbackManager(application.applicationContext)

    private val _currentScreen = MutableStateFlow(AppScreen.CAMERA)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _isLivePhotoEnabled = MutableStateFlow(true)
    val isLivePhotoEnabled: StateFlow<Boolean> = _isLivePhotoEnabled.asStateFlow()

    private val _flashState = MutableStateFlow(FlashState.AUTO)
    val flashState: StateFlow<FlashState> = _flashState.asStateFlow()

    private val _lensFacing = MutableStateFlow(CameraSelector.LENS_FACING_BACK)
    val lensFacing: StateFlow<Int> = _lensFacing.asStateFlow()

    private val _resolution = MutableStateFlow(CaptureResolution.UHD_4_3)
    val resolution: StateFlow<CaptureResolution> = _resolution.asStateFlow()

    private val _captureMode = MutableStateFlow(CameraCaptureMode.LIVE)
    val captureMode: StateFlow<CameraCaptureMode> = _captureMode.asStateFlow()

    private val _isCapturing = MutableStateFlow(false)
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    private val _shutterFlashEffect = MutableStateFlow(false)
    val shutterFlashEffect: StateFlow<Boolean> = _shutterFlashEffect.asStateFlow()

    private val _statusToast = MutableStateFlow<String?>(null)
    val statusToast: StateFlow<String?> = _statusToast.asStateFlow()

    private val _mediaFilter = MutableStateFlow(GalleryMediaFilter.ALL)
    val mediaFilter: StateFlow<GalleryMediaFilter> = _mediaFilter.asStateFlow()

    private val _dateFilter = MutableStateFlow(GalleryDateFilter.ALL_TIME)
    val dateFilter: StateFlow<GalleryDateFilter> = _dateFilter.asStateFlow()

    private val _selectedEntry = MutableStateFlow<LivePhotoEntry?>(null)
    val selectedEntry: StateFlow<LivePhotoEntry?> = _selectedEntry.asStateFlow()

    private val _showSettingsSheet = MutableStateFlow(false)
    val showSettingsSheet: StateFlow<Boolean> = _showSettingsSheet.asStateFlow()

    private val _enableGridLines = MutableStateFlow(true)
    val enableGridLines: StateFlow<Boolean> = _enableGridLines.asStateFlow()

    val allEntries: StateFlow<List<LivePhotoEntry>> = repository.entries

    val filteredEntries: StateFlow<List<LivePhotoEntry>> = combine(
        repository.entries,
        _mediaFilter,
        _dateFilter
    ) { entries, mediaF, dateF ->
        repository.filterEntries(entries, mediaF, dateF)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.loadEntries()
        }
    }

    fun toggleLivePhoto() {
        val next = !_isLivePhotoEnabled.value
        _isLivePhotoEnabled.value = next
        cameraController.setLiveBufferingEnabled(next)
        haptics.performModeTick()
        showToast(if (next) "LIVE AKTIF (1.5s Pra + 1.5s Pasca)" else "LIVE NONAKTIF")
    }

    fun cycleFlashState() {
        val next = _flashState.value.next()
        _flashState.value = next
        cameraController.setFlashMode(next)
        haptics.performModeTick()
        showToast("Flash: ${next.label}")
    }

    fun switchCameraLens() {
        val next = if (_lensFacing.value == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        _lensFacing.value = next
        haptics.performModeTick()
    }

    fun selectResolution(res: CaptureResolution) {
        _resolution.value = res
        haptics.performModeTick()
        showToast("Resolusi: ${res.title}")
    }

    fun cycleResolution() {
        selectResolution(_resolution.value.next())
    }

    fun selectCaptureMode(mode: CameraCaptureMode) {
        _captureMode.value = mode
        mode.forceLive?.let { forced ->
            _isLivePhotoEnabled.value = forced
            cameraController.setLiveBufferingEnabled(forced)
        }
        haptics.performModeTick()
    }

    fun setSettingsSheetVisible(visible: Boolean) {
        _showSettingsSheet.value = visible
    }

    fun toggleGridLines() {
        _enableGridLines.value = !_enableGridLines.value
    }

    fun capturePhoto() {
        if (_isCapturing.value) return
        viewModelScope.launch {
            _isCapturing.value = true
            _shutterFlashEffect.value = true
            haptics.performShutterTap()

            val liveActive = _isLivePhotoEnabled.value
            val currentRes = _resolution.value
            val currentLens = _lensFacing.value

            // Hide visual flash overlay quickly while post-shutter Live Photo frames finish recording
            launch {
                kotlinx.coroutines.delay(110L)
                _shutterFlashEffect.value = false
            }

            val captureResult = cameraController.capturePhotoAndLiveClip(
                captureLivePhoto = liveActive,
                lensFacing = currentLens
            )

            captureResult.onSuccess { (photoFile, videoFile) ->
                val saveResult = repository.saveCaptureToMediaStore(
                    tempPhotoFile = photoFile,
                    tempVideoFile = videoFile,
                    isLivePhoto = liveActive && videoFile != null,
                    resolutionBadge = currentRes.badge,
                    lensFacing = currentLens,
                    durationMs = 3000L
                )
                saveResult.onSuccess { entry ->
                    showToast(
                        if (entry.isLivePhoto) "Live Photo tersimpan di Galeri"
                        else "Foto tersimpan di Galeri"
                    )
                }.onFailure { err ->
                    showToast("Gagal menyimpan ke MediaStore: ${err.localizedMessage ?: "Error"}")
                }
            }.onFailure { err ->
                showToast("Gagal mengambil foto: ${err.localizedMessage ?: "Error"}")
            }

            _isCapturing.value = false
        }
    }

    fun openGallery() {
        viewModelScope.launch {
            repository.loadEntries()
        }
        _currentScreen.value = AppScreen.GALLERY
    }

    fun openCamera() {
        _currentScreen.value = AppScreen.CAMERA
    }

    fun openFullscreenViewer(entry: LivePhotoEntry) {
        _selectedEntry.value = entry
        _currentScreen.value = AppScreen.FULLSCREEN_VIEWER
    }

    fun setMediaFilter(filter: GalleryMediaFilter) {
        _mediaFilter.value = filter
    }

    fun setDateFilter(filter: GalleryDateFilter) {
        _dateFilter.value = filter
    }

    fun deleteEntry(entry: LivePhotoEntry) {
        viewModelScope.launch {
            repository.deleteEntry(entry)
            showToast("${entry.displayName} dihapus")
            if (_selectedEntry.value?.id == entry.id) {
                val remaining = repository.entries.value
                if (remaining.isNotEmpty()) {
                    _selectedEntry.value = remaining.first()
                } else {
                    _selectedEntry.value = null
                    _currentScreen.value = AppScreen.GALLERY
                }
            }
        }
    }

    fun exportJpeg(entry: LivePhotoEntry) {
        viewModelScope.launch {
            repository.exportStandaloneJpeg(entry)
                .onSuccess {
                    showToast("JPEG diekspor ke Pictures/iLiveCamera_Exports")
                }
                .onFailure {
                    showToast("Gagal mengekspor JPEG: ${it.localizedMessage ?: "Error"}")
                }
        }
    }

    fun exportMp4(entry: LivePhotoEntry) {
        viewModelScope.launch {
            repository.exportStandaloneMp4(entry)
                .onSuccess {
                    showToast("Klip gerakan MP4 diekspor ke Movies/iLiveCamera_Exports")
                }
                .onFailure {
                    showToast("Gagal mengekspor MP4: ${it.localizedMessage ?: "Error"}")
                }
        }
    }

    fun buildShareIntent(entry: LivePhotoEntry, shareMotionVideo: Boolean): Intent {
        return repository.createShareIntent(entry, shareMotionVideo)
    }

    fun clearToast() {
        _statusToast.value = null
    }

    fun showToast(message: String) {
        _statusToast.value = message
    }

    override fun onCleared() {
        super.onCleared()
        cameraController.shutdown()
    }
}
