package com.ilive.camera.model

import android.net.Uri
import android.util.Size
import androidx.camera.core.ImageCapture

enum class FlashState(val label: String, val cameraXMode: Int) {
    AUTO("Auto", ImageCapture.FLASH_MODE_AUTO),
    ON("On", ImageCapture.FLASH_MODE_ON),
    OFF("Off", ImageCapture.FLASH_MODE_OFF);

    fun next(): FlashState = when (this) {
        AUTO -> ON
        ON -> OFF
        OFF -> AUTO
    }
}

enum class CaptureResolution(
    val id: String,
    val title: String,
    val badge: String,
    val aspectRatioText: String,
    val targetSize: Size,
    val aspectRatioFloat: Float
) {
    UHD_4_3(
        id = "UHD_4_3",
        title = "12 MP Standard (4:3)",
        badge = "4:3",
        aspectRatioText = "4:3",
        targetSize = Size(3000, 4000),
        aspectRatioFloat = 3f / 4f
    ),
    FHD_16_9(
        id = "FHD_16_9",
        title = "Widescreen HD (16:9)",
        badge = "16:9",
        aspectRatioText = "16:9",
        targetSize = Size(2160, 3840),
        aspectRatioFloat = 9f / 16f
    ),
    SQUARE_1_1(
        id = "SQUARE_1_1",
        title = "Square Frame (1:1)",
        badge = "1:1",
        aspectRatioText = "1:1",
        targetSize = Size(3000, 3000),
        aspectRatioFloat = 1f
    );

    fun next(): CaptureResolution = when (this) {
        UHD_4_3 -> FHD_16_9
        FHD_16_9 -> SQUARE_1_1
        SQUARE_1_1 -> UHD_4_3
    }
}

enum class CameraCaptureMode(val displayName: String, val forceLive: Boolean?) {
    LIVE("LIVE", true),
    PHOTO("PHOTO", false),
    PORTRAIT("PORTRAIT", null)
}

enum class GalleryMediaFilter(val label: String) {
    ALL("Semua Media"),
    LIVE_ONLY("Live Photo"),
    STILL_ONLY("Foto Standar")
}

enum class GalleryDateFilter(val label: String) {
    ALL_TIME("Semua Waktu"),
    TODAY("Hari Ini"),
    LAST_7_DAYS("7 Hari Terakhir"),
    THIS_MONTH("Bulan Ini")
}

data class LivePhotoEntry(
    val id: String,
    val timestampMs: Long,
    val displayName: String,
    val photoUri: Uri,
    val videoUri: Uri?,
    val isLivePhoto: Boolean,
    val width: Int,
    val height: Int,
    val resolutionBadge: String,
    val lensFacing: Int,
    val durationMs: Long = 3000L,
    val sizeBytes: Long = 0L
)
