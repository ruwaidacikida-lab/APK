package com.ilive.camera.ui.components

import android.net.Uri
import android.view.ViewGroup
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage

/**
 * Displays a still high-res JPEG and seamlessly crossfades + scales to the synchronized
 * motion MP4 video clip while the user presses and holds on the image (just like iOS Live Photos).
 */
@Composable
fun LivePhotoInteractiveView(
    photoUri: Uri,
    videoUri: Uri?,
    isLivePhoto: Boolean,
    externalHoldPlaying: Boolean = false,
    onTap: (() -> Unit)? = null,
    onHoldStart: (() -> Unit)? = null,
    onHoldEnd: (() -> Unit)? = null,
    contentScale: ContentScale = ContentScale.Crop,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isInternalHolding by remember { mutableStateOf(false) }
    val shouldPlayMotion = isLivePhoto && videoUri != null && (isInternalHolding || externalHoldPlaying)

    val zoomScale by animateFloatAsState(
        targetValue = if (shouldPlayMotion) 1.045f else 1.0f,
        animationSpec = tween(durationMillis = 280),
        label = "live_hold_scale"
    )

    val exoPlayer = remember(videoUri) {
        if (isLivePhoto && videoUri != null) {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(videoUri))
                repeatMode = Player.REPEAT_MODE_ONE
                prepare()
                playWhenReady = false
            }
        } else {
            null
        }
    }

    LaunchedEffect(shouldPlayMotion) {
        if (exoPlayer != null) {
            if (shouldPlayMotion) {
                exoPlayer.seekTo(0L)
                exoPlayer.playWhenReady = true
            } else {
                exoPlayer.playWhenReady = false
            }
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer?.release()
        }
    }

    Box(
        modifier = modifier
            .scale(zoomScale)
            .pointerInput(isLivePhoto, videoUri) {
                detectTapGestures(
                    onTap = { onTap?.invoke() },
                    onLongPress = {
                        if (isLivePhoto && videoUri != null) {
                            isInternalHolding = true
                            onHoldStart?.invoke()
                        }
                    },
                    onPress = {
                        tryAwaitRelease()
                        if (isInternalHolding) {
                            isInternalHolding = false
                            onHoldEnd?.invoke()
                        }
                    }
                )
            }
    ) {
        // Base Still Photo
        AsyncImage(
            model = photoUri,
            contentDescription = "Live Photo",
            contentScale = contentScale,
            modifier = Modifier.fillMaxSize()
        )

        // Motion Video Overlay (Crossfades smoothly without black flicker)
        if (isLivePhoto && exoPlayer != null) {
            AnimatedVisibility(
                visible = shouldPlayMotion,
                enter = fadeIn(tween(180)),
                exit = fadeOut(tween(220))
            ) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            resizeMode = if (contentScale == ContentScale.Crop) {
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            } else {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            player = exoPlayer
                        }
                    },
                    update = { view ->
                        view.player = exoPlayer
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
