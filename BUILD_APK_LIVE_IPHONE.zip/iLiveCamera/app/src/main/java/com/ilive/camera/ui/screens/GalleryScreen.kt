package com.ilive.camera.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ilive.camera.model.GalleryDateFilter
import com.ilive.camera.model.GalleryMediaFilter
import com.ilive.camera.model.LivePhotoEntry
import com.ilive.camera.ui.components.LivePhotoInteractiveView
import com.ilive.camera.ui.components.LivePhotoRingsIcon
import com.ilive.camera.ui.components.LiveStatusPill
import com.ilive.camera.ui.theme.ILiveBlack
import com.ilive.camera.ui.theme.ILiveDanger
import com.ilive.camera.ui.theme.ILiveGold
import com.ilive.camera.ui.theme.ILiveGray
import com.ilive.camera.ui.theme.ILiveSurface
import com.ilive.camera.ui.theme.ILiveWhite
import com.ilive.camera.viewmodel.CameraViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GalleryScreen(
    viewModel: CameraViewModel
) {
    val entries by viewModel.filteredEntries.collectAsState()
    val mediaFilter by viewModel.mediaFilter.collectAsState()
    val dateFilter by viewModel.dateFilter.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ILiveBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = { viewModel.openCamera() },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(ILiveSurface)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Kembali ke Kamera",
                        tint = ILiveWhite
                    )
                }
                Column {
                    Text(
                        text = "Galeri iLive",
                        color = ILiveWhite,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${entries.size} item • Tekan & tahan untuk memutar Live Photo",
                        color = ILiveGray,
                        fontSize = 11.sp
                    )
                }
            }

            IconButton(
                onClick = { viewModel.openCamera() },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(ILiveGold)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Kamera",
                    tint = Color.Black
                )
            }
        }

        // Filter Bar: Media Type Filter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GalleryMediaFilter.values().forEach { filter ->
                val selected = mediaFilter == filter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (selected) ILiveGold else ILiveSurface)
                        .clickable { viewModel.setMediaFilter(filter) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = filter.label,
                        color = if (selected) Color.Black else ILiveWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Filter Bar: Date Range Filter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GalleryDateFilter.values().forEach { filter ->
                val selected = dateFilter == filter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (selected) Color.White.copy(alpha = 0.2f) else Color.Transparent)
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(50))
                        .clickable { viewModel.setDateFilter(filter) }
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = filter.label,
                        color = if (selected) ILiveGold else ILiveGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (entries.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LivePhotoRingsIcon(active = true, size = 48.dp)
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Belum ada foto pada filter ini",
                        color = ILiveWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Ambil momen Live Photo dari kamera untuk melihat dan memutar gerakan foto di sini.",
                        color = ILiveGray,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(entries, key = { it.id }) { entry ->
                    GalleryGridTile(
                        entry = entry,
                        onOpenFullscreen = { viewModel.openFullscreenViewer(entry) },
                        onHoldFeedback = { viewModel.haptics.performLiveHoldTick() }
                    )
                }
            }
        }
    }
}

@Composable
private fun GalleryGridTile(
    entry: LivePhotoEntry,
    onOpenFullscreen: () -> Unit,
    onHoldFeedback: () -> Unit
) {
    var isHoldingTile by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .aspectRatio(0.78f)
            .clip(RoundedCornerShape(12.dp))
            .background(ILiveSurface)
    ) {
        LivePhotoInteractiveView(
            photoUri = entry.photoUri,
            videoUri = entry.videoUri,
            isLivePhoto = entry.isLivePhoto,
            onTap = onOpenFullscreen,
            onHoldStart = {
                isHoldingTile = true
                onHoldFeedback()
            },
            onHoldEnd = {
                isHoldingTile = false
            },
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Top-left LIVE indicator badge on every Live Photo tile
        if (entry.isLivePhoto) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (isHoldingTile) ILiveGold else Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                LivePhotoRingsIcon(
                    active = true,
                    isPlayingOrRecording = isHoldingTile,
                    size = 11.dp,
                    tint = if (isHoldingTile) Color.Black else ILiveGold
                )
                Text(
                    text = "LIVE",
                    color = if (isHoldingTile) Color.Black else ILiveWhite,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun FullscreenViewerScreen(
    viewModel: CameraViewModel
) {
    val context = LocalContext.current
    val entry by viewModel.selectedEntry.collectAsState()
    val currentEntry = entry ?: run {
        viewModel.openGallery()
        return
    }

    var isButtonHoldingPlay by remember { mutableStateOf(false) }
    val formattedDate = remember(currentEntry.timestampMs) {
        SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.getDefault()).format(Date(currentEntry.timestampMs))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ILiveBlack)
    ) {
        // Fullscreen Interactive Live Photo View (Press & Hold anywhere on image to play motion)
        LivePhotoInteractiveView(
            photoUri = currentEntry.photoUri,
            videoUri = currentEntry.videoUri,
            isLivePhoto = currentEntry.isLivePhoto,
            externalHoldPlaying = isButtonHoldingPlay,
            onHoldStart = { viewModel.haptics.performLiveHoldTick() },
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )

        // Top Overlay Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = { viewModel.openGallery() },
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Kembali ke Galeri",
                    tint = ILiveWhite
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = currentEntry.displayName,
                    color = ILiveWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "$formattedDate • ${currentEntry.resolutionBadge}",
                    color = ILiveGray,
                    fontSize = 11.sp
                )
            }

            if (currentEntry.isLivePhoto) {
                LiveStatusPill(
                    isLiveEnabled = true,
                    isCapturingOrPlaying = isButtonHoldingPlay,
                    onClick = {
                        isButtonHoldingPlay = !isButtonHoldingPlay
                        viewModel.haptics.performLiveHoldTick()
                    }
                )
            } else {
                Spacer(modifier = Modifier.size(42.dp))
            }
        }

        // Bottom Action Deck: Share, Export JPEG, Export MP4, Delete
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 16.dp)
                .align(Alignment.BottomCenter),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (currentEntry.isLivePhoto) {
                Text(
                    text = "Tekan & tahan foto atau ketuk badge LIVE untuk memutar gerakan",
                    color = ILiveGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(ILiveSurface.copy(alpha = 0.92f))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Share Action
                ActionColumnButton(
                    icon = Icons.Default.Share,
                    label = "Bagikan",
                    tint = ILiveWhite,
                    onClick = {
                        val intent = viewModel.buildShareIntent(currentEntry, shareMotionVideo = false)
                        context.startActivity(android.content.Intent.createChooser(intent, "Bagikan Foto"))
                    }
                )

                // Export JPEG Action
                ActionColumnButton(
                    icon = Icons.Default.FileDownload,
                    label = "Ekspor JPEG",
                    tint = ILiveWhite,
                    onClick = { viewModel.exportJpeg(currentEntry) }
                )

                // Export MP4 Motion Clip Action (Available for Live Photos)
                if (currentEntry.isLivePhoto && currentEntry.videoUri != null) {
                    ActionColumnButton(
                        icon = Icons.Default.MovieCreation,
                        label = "Ekspor MP4",
                        tint = ILiveGold,
                        onClick = { viewModel.exportMp4(currentEntry) }
                    )
                }

                // Delete Action
                ActionColumnButton(
                    icon = Icons.Default.DeleteOutline,
                    label = "Hapus",
                    tint = ILiveDanger,
                    onClick = { viewModel.deleteEntry(currentEntry) }
                )
            }
        }
    }
}

@Composable
private fun ActionColumnButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = tint,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
