-keepattributes *Annotation*
-keepclassmembers class * {
    @org.jetbrains.annotations.* *;
}
-dontwarn androidx.camera.**
-dontwarn androidx.media3.**
