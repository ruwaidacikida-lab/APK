#!/usr/bin/env bash
set -e

echo "==================================================="
echo "  iLive Camera - Automated APK Builder"
echo "==================================================="

if ! command -v java >/dev/null 2>&1; then
  echo "[!] Java (JDK 17) belum terinstal. Silakan instal OpenJDK 17 terlebih dahulu."
  exit 1
fi

if [ -x "./gradlew" ]; then
  echo "[*] Menjalankan ./gradlew assembleDebug..."
  ./gradlew assembleDebug --stacktrace
elif command -v gradle >/dev/null 2>&1; then
  echo "[*] Menjalankan gradle assembleDebug..."
  gradle assembleDebug --stacktrace
else
  echo "[!] Gradle belum terinstal di sistem Anda."
  echo "    Instal Gradle 8.6+ atau buka project ini di Android Studio."
  exit 1
fi

echo ""
echo "[✓] BUILD BERHASIL!"
echo "    File APK tersedia di: app/build/outputs/apk/debug/app-debug.apk"
