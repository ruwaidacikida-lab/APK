@echo off
echo ===================================================
echo   iLive Camera - Automated APK Builder (Windows)
echo ===================================================

where java >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Java ^(JDK 17^) belum ditemukan di PATH.
    exit /b 1
)

if exist "gradlew.bat" (
    echo [*] Menjalankan gradlew.bat assembleDebug...
    call gradlew.bat assembleDebug --stacktrace
) else (
    echo [*] Menjalankan gradle assembleDebug...
    call gradle assembleDebug --stacktrace
)

echo.
echo [OK] File APK tersedia di: app\build\outputs\apk\debug\app-debug.apk
pause
