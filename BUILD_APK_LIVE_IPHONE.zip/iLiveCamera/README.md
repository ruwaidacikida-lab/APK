# iLive Camera — Android Native Live Photo Camera App

**iLive Camera** adalah aplikasi kamera native Android berbasis **Kotlin**, **CameraX**, **Jetpack Compose (Material 3)**, dan **Media3 ExoPlayer** yang menghadirkan pengalaman **Live Photo** (merekam momen bergerak ~1.5 detik sebelum dan ~1.5 detik sesudah tombol shutter ditekan) dengan desain minimalis, modern, dan elegan yang terinspirasi dari pengalaman iPhone Camera.

---

## 1. Arsitektur & Cara Kerja Fitur Utama

### A. Rolling Live Photo Engine (`LiveCameraController.kt`)
- **Circular Pre-Shutter Buffer (RAM-Optimized)**: Saat fitur **LIVE** aktif, `ImageAnalysis` dengan `STRATEGY_KEEP_ONLY_LATEST` menyampling frame YUV_420_888 secara asynchronous di background thread pada ~15 FPS ke dalam *ring buffer* terbatas (`ArrayDeque` maksimal 23 frame pra-shutter, penggunaan RAM hanya ~3–4 MB).
- **Zero-Shutter-Lag Primary Capture**: Saat tombol shutter ditekan, `ImageCapture` (`CAPTURE_MODE_MINIMIZE_LATENCY`) langsung menangkap foto utama beresolusi penuh (JPEG) sementara *ring buffer* mengambil snapshot 1.5 detik sebelum shutter dan melanjutkan perekaman 1.5 detik setelah shutter.
- **Hardware H.264 Encoding (`MediaCodec` + `MediaMuxer`)**: Rangkaian frame sebelum dan sesudah shutter digabungkan dengan *presentation timestamp* monotonik dan di-encode di background thread menjadi klip video `.mp4` (H.264/AVC) yang halus tanpa membebani UI thread.

### B. Penyimpanan MediaStore & Pairing Metadata (`LivePhotoRepository.kt`)
- **Penyimpanan Galeri Android (`MediaStore`)**:
  - Foto utama disimpan ke `DCIM/iLiveCamera/ILIVE_<TIMESTAMP>_<ID>.jpg`.
  - Klip gerakan disimpan ke `DCIM/iLiveCamera/ILIVE_<TIMESTAMP>_<ID>_LIVE.mp4`.
- **Sinkronisasi Metadata Pasangan Foto-Video**:
  - Menyimpan ID pasangan (`ILIVE_PAIR_ID:<ID>`) di dalam tag EXIF `UserComment` pada file JPEG menggunakan `androidx.exifinterface` serta indeks lokal cepat (`live_photo_index.json`) dengan pemindaian fallback otomatis ke `MediaStore`.
  - Tidak mengklaim kompatibilitas metadata proprieter Apple Live Photos (`ContentIdentifier` QuickTime), melainkan menyediakan **Ekspor JPEG Standar** (`Pictures/iLiveCamera_Exports`) dan **Ekspor Klip Gerakan MP4** (`Movies/iLiveCamera_Exports`) secara eksplisit.

### C. Pengalaman UI/UX & Galeri (`CameraScreen.kt`, `GalleryScreen.kt`, `LivePhotoInteractiveView.kt`)
- **Kontrol Kamera Lengkap**:
  - Preview real-time memenuhi layar dengan transisi rasio aspek (`4:3`, `16:9`, `1:1`).
  - **Tap-to-Focus & Exposure Metering** dengan indikator fokus animasi kuning khas.
  - **Pinch-to-Zoom** halus beserta tombol preset cepat (`1x`, `2x`, `3x`).
  - **Flash Siklik**: `Auto`, `On`, `Off`.
  - **Kamera Depan & Belakang** dengan rotasi ikon adaptif mengikuti sensor orientasi perangkat.
  - **Feedback Visual & Haptic**: Efek kedipan layar singkat dan getaran presisi (`VibrationEffect.EFFECT_CLICK` / `EFFECT_TICK`) saat memotret dan menahan Live Photo.
- **Galeri Khusus Live Photo**:
  - Grid thumbnail berkualitas tinggi menggunakan **Coil** (`VideoFrameDecoder`).
  - Badge **LIVE** konsentris pada setiap foto Live Photo.
  - **Tekan & Tahan (Long-Press)** pada grid maupun tampilan layar penuh untuk memutar gerakan Live Photo secara mulus dengan **Media3 ExoPlayer** dan efek *smooth zoom-in*.
  - Filter berdasarkan jenis media (**Semua Media**, **Live Photo**, **Foto Standar**) dan rentang waktu (**Semua Waktu**, **Hari Ini**, **7 Hari Terakhir**, **Bulan Ini**).

---

## 2. Struktur Direktori Project

```text
iLiveCamera/
├── .github/workflows/
│   └── build-debug-apk.yml          # Workflow CI otomatis untuk build file APK Debug di GitHub Actions
├── app/
│   ├── build.gradle.kts             # Konfigurasi modul aplikasi, CameraX, Compose, Media3, Coil
│   ├── proguard-rules.pro           # Aturan ProGuard/R8
│   └── src/main/
│       ├── AndroidManifest.xml      # Izin Kamera, MediaStore (Android 8.0 - 14+), FileProvider
│       ├── java/com/ilive/camera/
│       │   ├── iLiveApplication.kt  # Konfigurasi CameraX & Coil ImageLoader
│       │   ├── MainActivity.kt      # Penanganan Permission runtime & navigasi utama
│       │   ├── camera/
│       │   │   └── LiveCameraController.kt  # Engine CameraX + Rolling Buffer + MediaCodec MP4 Muxer
│       │   ├── data/
│       │   │   └── LivePhotoRepository.kt   # Pengelolaan MediaStore, EXIF pairing, Ekspor JPEG & MP4
│       │   ├── model/
│       │   │   └── CameraModels.kt          # Data class & enum state kamera dan galeri
│       │   ├── ui/
│       │   │   ├── components/
│       │   │   │   ├── LiveBadgeComponents.kt         # Ikon cincin konsentris LIVE & pill status
│       │   │   │   └── LivePhotoInteractiveView.kt    # Komponen Tekan-dan-Tahan pemutar Live Photo
│       │   │   ├── screens/
│       │   │   │   ├── CameraScreen.kt                # Layar utama kamera
│       │   │   │   └── GalleryScreen.kt               # Layar galeri & fullscreen viewer
│       │   │   └── theme/
│       │   │       └── Theme.kt                       # Palet warna hitam/putih/emas minimalis
│       │   ├── util/
│       │   │   └── HapticFeedbackManager.kt           # Getaran shutter & interaksi Live Photo
│       │   └── viewmodel/
│       │       └── CameraViewModel.kt                 # StateFlow arsitektur MVVM
│       └── res/
│           ├── drawable/            # Vektor ikon adaptif iLive Camera
│           ├── mipmap-anydpi-v26/   # Launcher icon
│           ├── values/              # Strings & tema layar penuh
│           └── xml/                 # Konfigurasi FileProvider
├── build.gradle.kts                 # Root Gradle build script
├── gradle.properties                # Optimasi JVM & AndroidX
├── gradle/libs.versions.toml        # Version Catalog seluruh dependency stabil
└── settings.gradle.kts              # Konfigurasi repositori Google & MavenCentral
```

---

## 3. Cara Build Menjadi File APK (`app-debug.apk`)

> **Catatan Lingkungan Sandbox**: Lingkungan VM pembuat kode ini berjalan secara *offline* tanpa instalasi Android SDK (`aapt2`, `d8`, `android.jar`), sehingga kompilasi biner `.apk` dilakukan melalui **Android Studio**, **Command Line Gradle**, atau **GitHub Actions (1-Klik di Cloud)** menggunakan konfigurasi yang sudah disertakan di dalam project ini.

### Opsi 1 — Build via Android Studio (Direkomendasikan)
1. Ekstrak file `iLiveCamera-Android-Project.zip`.
2. Buka **Android Studio** (Iguana / Jellyfish / Koala atau lebih baru dengan JDK 17).
3. Pilih **Open** dan arahkan ke folder `iLiveCamera`.
4. Tunggu proses **Gradle Sync** selesai mengunduh dependency dari Google Maven & MavenCentral.
5. Klik menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. File APK siap diinstal berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

### Opsi 2 — Build via Terminal / Command Line
Pastikan variabel `ANDROID_HOME` mengarah ke Android SDK (API 34) dan JDK 17 aktif:
```bash
cd iLiveCamera
gradle assembleDebug
```
Untuk langsung menginstal ke perangkat Android yang terhubung via USB Debugging:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Opsi 3 — Build Otomatis Tanpa Android Studio (GitHub Actions)
1. Unggah isi folder `iLiveCamera` ke repositori GitHub Anda.
2. Buka tab **Actions** di repositori GitHub.
3. Jalankan workflow **Build iLive Camera Debug APK** (otomatis berjalan setiap *push* atau klik **Run workflow**).
4. Unduh file `iLiveCamera-debug-apk.zip` yang berisi `app-debug.apk` siap instal di ponsel Android (Android 8.0 / API 26 ke atas).
